package com.example.demo.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.AppService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.AppModel;

@RestController
public class AppController {
    @Autowired
    AppService service;
    @PostMapping("/create")
    public AppModel create(@RequestBody AppModel take1){
       return service.create(take1);
    }
    
    
}